const moment = require('moment');
const thanks = {
    "en": "Thank you, Thanks",
    "fr": "Merci",
    "hi": "Dhanyavad",
    "es": "gracias",
    "jp": "arigato",
    "ru": "spasiba",
	"it": "Grazie",
    "gr": "danke" 
}

// Async handler
exports.handler = async (event) => {
    // path parameter
    let name = event.pathParameters.name;

    // query parameter
    let {lang, ...info} = event.queryStringParameters || {};

    let message = `${thanks[lang] ? thanks[lang] : thanks['en'] } ${name}`;
    let response = {
        message: message,
        info: info,
        timestamp: moment().unix()
    }
    // return http response body for api gateway
    return {
        statusCode: 200,
        body: JSON.stringify(response)
    }
}